/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_ultimate_ft.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bcaumont <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/04 23:48:05 by bcaumont          #+#    #+#             */
/*   Updated: 2024/07/05 00:15:58 by bcaumont         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <stdio.h>

void	ft_ultimate_ft(int *********nbr)
{
	*********nbr = 42;
}
/*
int	main(void)
{
	int	n;
	int	*n1 = &n;
	int	**n2 = &n1;
	int	***n3 = &n2;
	int	****n4 = &n3;
	int	*****n5 = &n4;
	int	******n6 = &n5;
	int	*******n7 = &n6;
	int	********n8 = &n7;
	int	*********n9 = &n8;
	
	n = 0;
	printf("avant: %d\n", n);
	ft_ultimate_ft(n9);
	printf("apres: %d\n", n);
	return(0);
}
*/
