/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strupcase.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bcaumont <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/08 15:30:58 by bcaumont          #+#    #+#             */
/*   Updated: 2024/07/08 15:31:01 by bcaumont         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <stdio.h>

char	*ft_strupcase(char *str)
{
	int	c;

	c = 0;
	while (str[c] != '\0')
	{
		if (str[c] >= 'a' && str[c] <= 'z')
		{
			str[c] = str[c] - ('a' - 'A');
		}
		c++;
	}
	return (str);
}
/*
int	main(void)
{
	char	test0[] = "wuefuih5456dwq";
	char	test1[] = "wuefuih5456dwq";
	char	test2[] = "";
		
	printf("avant test: %s\n", test0);
	printf("apres test: %s\n", ft_strupcase(test1));
	printf("test du vide: %s\n", ft_strupcase(test2));
	return (0);
}
*/
