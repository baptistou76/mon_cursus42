/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlowcase.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bcaumont <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/08 17:10:08 by bcaumont          #+#    #+#             */
/*   Updated: 2024/07/08 17:10:11 by bcaumont         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

char	*ft_strlowcase(char *str)
{
	int	c;

	c = 0;
	while (str[c] != '\0')
	{
		if (str[c] >= 65 && str[c] <= 90)
		{
			str[c] += 32;
		}
		c++;
	}
	return (str);
}
/*
int	main(void)
{
	char	test0[] = "UGGWYUHX";
	char	test1[] = "hwfhwfjk";
	char	test2[] = "";
	
	printf("avant test: %s\n", test0);
	printf("test: %s\n", ft_strlowcase(test1));
	printf("test du vide: %s\n", ft_strlowcase(test2));
	return (0);
}
*/
