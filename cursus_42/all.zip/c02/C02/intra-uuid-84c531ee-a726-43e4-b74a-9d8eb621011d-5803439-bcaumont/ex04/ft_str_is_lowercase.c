/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_lowercase.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bcaumont <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/08 12:39:16 by bcaumont          #+#    #+#             */
/*   Updated: 2024/07/08 12:39:20 by bcaumont         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

int	ft_str_is_lowercase(char *str)
{
	int	c;

	c = 0;
	if (str[c] == '\0')
		return (1);
	while (str[c] != '\0')
	{
		if (!(str[c] >= 'a' && str[c] <= 'z'))
			return (0);
		c++;
	}
	return (1);
}
/*
int	main(void)
{
	char	test0[]= "minuscules";
	char	test1[]= "MajusculeS";
	char	test2[]= "";
	
	printf("test 0: %s -> %d\n", test0, ft_str_is_lowercase(test0));
	printf("test 1: %s -> %d\n", test1, ft_str_is_lowercase(test1));
	printf("test 2: %s -> %d\n", test2, ft_str_is_lowercase(test2));
	return (0);
}
*/
