/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putstr_non_printable.c                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bcaumont <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/09 11:51:02 by bcaumont          #+#    #+#             */
/*   Updated: 2024/07/09 11:51:06 by bcaumont         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_putchar(char c)
{
	write (1, &c, 1);
}

void	ft_putstr_non_printable(char *str)
{
	int	c;
		
	c = 0;
	while (str[c] != '\0')
	{
		if (str[c] >= 32 && str[c] <= 126)
		{
			ft_putchar(str[c]);
		}
		else
		{
			ft_putchar('\\');
			ft_putchar("0123456789abcdef"[str[c] / 16]);
			ft_putchar("0123456789abcdef"[str[c] % 16]);
		}
		c++;
	}
}
/*
int	main(void)
{
	char	test[] = "coucou\ntu va bien ?";
	
	ft_putstr_non_printable(test);
	return (0);
}
*/
