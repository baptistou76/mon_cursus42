/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_alpha.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bcaumont <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/08 08:53:48 by bcaumont          #+#    #+#             */
/*   Updated: 2024/07/08 08:54:10 by bcaumont         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

int	ft_str_is_alpha(char *str)
{
	int	c;

	c = 0;
	if (str[c] == '\0')
		return (1);
	while (str[c] != '\0')
	{
		if (!((str[c] >= 'a' && str[c] <= 'z')
				|| (str[c] >= 'A' && str[c] <= 'Z')))
			return (0);
		c++;
	}
	return (1);
}
/*
int	main(void)
{
	char	test1[] = "ChaineDeLettres";
	char	test2[] = "chaine1234";
	char	test3[] = "";
	
	printf("test 1: %s -> %d\n", test1, ft_str_is_alpha(test1));
	printf("test 2: %s -> %d\n", test2, ft_str_is_alpha(test2));
	printf("test 3: %s -> %d\n", test3, ft_str_is_alpha(test3));
	return (0);
}
*/
