/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_uppercase.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bcaumont <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/08 13:44:42 by bcaumont          #+#    #+#             */
/*   Updated: 2024/07/08 13:44:48 by bcaumont         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

int	ft_str_is_uppercase(char *str)
{
	int	c;

	c = 0;
	if (str[c] == '\0')
		return (1);
	while (str[c] != '\0')
	{
		if (!(str[c] >= 'A' && str[c] <= 'Z'))
			return (0);
		c++;
	}
	return (1);
}
/*
int	main(void)
{
	char	test0[] = "tfehfe";
	char	test1[] = "MAJUSCULES";
	char	test2[] = "";
	
	printf("test 0: %s -> %d\n", test0, ft_str_is_uppercase(test0));
	printf("test 1: %s -> %d\n", test1, ft_str_is_uppercase(test1));
	printf("test 2: %s -> %d\n", test2, ft_str_is_uppercase(test2));
	return (0);
}
*/
