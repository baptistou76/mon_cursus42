/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_capitalize.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bcaumont <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/09 10:31:10 by bcaumont          #+#    #+#             */
/*   Updated: 2024/07/09 10:31:16 by bcaumont         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

char	*ft_lowercase(char *str)
{
	int	c;

	c = 0;
	while (str[c] != '\0')
	{
		if (str[c] >= 65 && str[c] <= 90)
			str[c] += 32;
		c++;
	}
	return (str);
}

char	*ft_strcapitalize(char *str)
{
	int	c;

	c = 0;
	ft_lowercase(str);
	while (str[c])
	{
		if (str[c] >= 97 && str[c] <= 122)
		{
			if (!(str[c - 1] >= 48 && str[c -1] <= 57)
				&& !(str[c - 1] >= 97 && str[c - 1] <= 122)
				&& !(str[c - 1] >= 65 && str[c - 1] <= 90))
				str[c] -= 32;
		}
		c++;
	}
	return (str);
}
/*
int	main(void)
{
	char	test[] = "salut, comment tu vas ? 
	42mots quarante-deux; cinquante+et+un";
	
	printf("avant test: %s\n", test);
	printf("apres test: %s\n", ft_strcapitalize(test));
	return (0);
}
*/
