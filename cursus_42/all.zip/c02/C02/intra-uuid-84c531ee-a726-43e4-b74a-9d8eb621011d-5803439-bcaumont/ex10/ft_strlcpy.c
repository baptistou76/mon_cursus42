/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlcpy.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bcaumont <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/09 11:05:16 by bcaumont          #+#    #+#             */
/*   Updated: 2024/07/09 11:05:19 by bcaumont         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

unsigned int	ft_strlcpy(char *dest, char *src, unsigned int size)
{
	unsigned int	c;
	unsigned int	src_len;

	src_len = 0;
	while (src[src_len] != '\0')
	{
		src_len++;
	}
	if (size > 0)
	{
		c = 0;
		while (c < size - 1 && src[c] != '\0')
		{
			dest[c] = src[c];
			c++;
		}
		dest[c] = '\0';
	}
	return (src_len);
}
/*
int	main(void)
{
	char	src[] = "Bonjour tout le monde";
	char	dest[20];
	unsigned int	resultat = ft_strlcpy(dest, src, 8);
	
	printf("phrase test: %s\n", src);
	printf("taille de la chaine: %s\n", dest);
	printf("resultat de la copie: %u\n", resultat);
	return (0);
}
*/
