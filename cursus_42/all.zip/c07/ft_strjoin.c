/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strjoin.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bcaumont <bcaumont@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/17 18:52:31 by bcaumont          #+#    #+#             */
/*   Updated: 2024/07/17 19:42:00 by bcaumont         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <stdlib.h>

int     ft_strlen(char *str)
{
        int len;

        len = 0;
        while (str[len] != '\0')
            len++;
        return (len);
}

void    ft_strcpy(char *dest, char *src)
{
    while (*src)
    {
        *dest = *src;
        dest++;
        src++;
    }
    *dest = '\0';
}

char    *ft_strjoin(int size, char **strs, char *sep)
{
        char    *result;
        char    *ptr;
        int         total_len;
        int         sep_len;
        int         i;

        total_len = 0;
        sep_len = ft_strlen(sep);
        if (size == 0)
        {
                result = (char *)malloc(1 * sizeof(char));
                if (result == NULL)
                    return(NULL);
        }
        i = 0;
        while (i < size)
        {
                total_len += ft_strlen(strs[i]);
                i++;       
        }
        total
}