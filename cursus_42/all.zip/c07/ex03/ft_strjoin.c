/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strjoin.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bcaumont <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/17 01:22:37 by bcaumont          #+#    #+#             */
/*   Updated: 2024/07/17 01:22:40 by bcaumont         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <stdlib.h>
#include <stddef.h>

int	ft_strlen(char *str)
{
	int	len;

	len = 0;
	while (str[len] != '\0')
		len++;
	return (len);
}

char	*ft_strcat(char *dest, char *src)
{
	int	c;
	int	d;

	c = 0;
	while (dest[c] != '\0')
	{
		c++;
	}
	d = 0;
	while (src[d] != '\0')
	{
		dest[c] = src[d];
		c++;
		d++;
	}
	dest[c] = '\0';
	return (dest);
}

int	ft_control(int size, char *result)
{
	if (size == 0)
	{
		result = (char *)malloc(1 * sizeof(char));
		if (result == NULL)
			return (0);
		else
		{
			result[0] = '\0';
			return (1);
		}
	}
	return (0);
}

char	*ft_out(int size, char *result, char **strs, char *sep)
{
	int	i;

	i = 0;
	while (i < size)
	{
		ft_strcat(result, strs[i]);
		if (i < size - 1)
			ft_strcat(result, sep);
		i++;
	}
	return (result);
}

char	*ft_strjoin(int size, char **strs, char *sep)
{
	char	*result;
	char	*control;
	int		total_len;
	int		sep_len;
	int		i;

	total_len = 0;
	sep_len = ft_strlen(sep);
	control = "A";
	i = ft_control(size, control);
	if (i == 1)
		return (control);
	i = 0;
	while (i < size)
	{
		total_len += ft_strlen(strs[i]);
		i++;
	}
	total_len += sep_len *(size - 1);
	result = (char *)malloc((total_len + 1) * sizeof(char));
	if (result == NULL)
		return (NULL);
	result = ft_out(size, result, strs, sep);
	result[total_len + 1] = '\0';
	return (result);
}
/*
int	main()
{
	char	*strs[] = {"Bonjour", "a", "tous"};
	char	*sep = "; ";
	char	*result;
	int	size = 3;
	
	result = ft_strjoin(size, strs, sep);
	if (result != NULL)
	{
		printf("%s\n", result);
		//free(result);
	}
	else
	{
		printf("Error\n");
	}
	return (0);
}
*/
