/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strdup.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bcaumont <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/16 17:11:46 by bcaumont          #+#    #+#             */
/*   Updated: 2024/07/16 17:11:48 by bcaumont         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
#include <stdio.h>

char	*ft_strdup(char *src)
{
	char	*dup;
	int		i;
	int		j;

	i = 0;
	while (src[i] != '\0')
		i++;
	dup = (char *)malloc((i +1) * sizeof(char));
	if (dup == NULL)
		return (NULL);
	j = 0;
	while (j <= i)
	{
		dup[j] = src[j];
		j++;
	}
	return (dup);
}
/*
int	main()
{
	char *source = "bonjour tout le monde";
	char *copie;
	
	copie = ft_strdup(source);
	if (copie == NULL)
	{
		printf("erreur d'allocation memoire\n");
		return (1);
	}
	printf("chaine source : %s\n", source);
	printf("chaine copiee : %s\n", copie);
	free(copie);
	return (0);
}
*/
